# نتيجة Stage 2A FIX1

## إصلاح الملفات

- القرار: **GREEN**
- records: **529**
- safe defect files: **529**
- safe pristine hosts: **30**
- pair-ready records: **529**
- pair-ready hosts: **30**
- targeted redownload failures:
  **0**

## إعادة تجميد الهدف

- target source: `structure_json_magmom`
- binary labels changed:
  **99**
- prior/new label agreement:
  **0.8129**

## LOHO بعد التصحيح

- binary AUROC:
  **0.8066**
- binary balanced accuracy:
  **0.7550**
- ordinal QWK:
  **0.5144**
- ordinal class MAE:
  **0.7618**
- ordinal within-one accuracy:
  **0.7713**

## المرحلة التالية

`STAGE2B_GRAPH_DERIVED_BASELINES`

هذه المرحلة لم تدرب graph model. تدريب CDT-EGNN النهائي غير مسموح.

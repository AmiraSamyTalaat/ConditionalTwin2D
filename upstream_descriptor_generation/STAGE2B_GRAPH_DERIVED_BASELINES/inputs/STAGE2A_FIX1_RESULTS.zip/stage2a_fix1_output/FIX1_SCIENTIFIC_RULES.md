# Stage 2A FIX1 scientific rules

## Authoritative target

The structure-specific JSON `magmom` value is the authoritative supervised
target for this frozen structure set.

The prior table-derived value is retained only as an audit field.

## Why the target is reconciled

A target used for graph learning must be attached to the exact structure file.
When table metadata and the downloaded structure JSON disagree, the structure
JSON value is used to avoid training on a label from a different calculation
state or row.

## File naming

Raw structure files are stored by a case-insensitive-safe SHA-256 filename:

`<record_id_sha256>.json`

The original record ID remains in the manifest.

## Claims remain unchanged

- absolute defective-supercell magnetic moment only;
- no pristine-relative delta;
- no induced-magnetism claim;
- no graph training in this stage.
